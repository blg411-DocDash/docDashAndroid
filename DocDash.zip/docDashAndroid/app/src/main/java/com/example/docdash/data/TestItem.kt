package com.example.docdash.data

data class TestItem(
    var testNo: Int,
    var testDescription: String,
)
