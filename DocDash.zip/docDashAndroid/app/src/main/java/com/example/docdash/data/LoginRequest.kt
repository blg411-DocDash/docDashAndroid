package com.example.docdash.data

data class LoginRequest(
    var email: String?,
    var password: String?
)
