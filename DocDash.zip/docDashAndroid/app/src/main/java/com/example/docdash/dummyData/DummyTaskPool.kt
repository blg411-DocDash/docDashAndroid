package com.example.docdash.dummyData

import com.example.docdash.data.TaskListItem

object DummyTaskPool {
    var dummyPool :List<TaskListItem> = listOf(
        TaskListItem(1, "Task 1", "2021-01-01", "Not Started", "Test 1", "Patient 1", "Room 1"),
        TaskListItem(2, "Task 2", "2021-01-02", "Not Started", "Test 2", "Patient 2", "Room 2"),
        TaskListItem(3, "Task 3", "2021-01-03", "Not Started", "Test 3", "Patient 3", "Room 3"),
        TaskListItem(4, "Task 4", "2021-01-04", "Not Started", "Test 4", "Patient 4", "Room 4"),
        TaskListItem(5, "Task 5", "2021-01-05", "Not Started", "Test 5", "Patient 5", "Room 5"),
        TaskListItem(6, "Task 6", "2021-01-06", "Not Started", "Test 6", "Patient 6", "Room 6"),
        TaskListItem(7, "Task 7", "2021-01-07", "Not Started", "Test 7", "Patient 7", "Room 7"),
        TaskListItem(8, "Task 8", "2021-01-08", "Not Started", "Test 8", "Patient 8", "Room 8"),
        TaskListItem(9, "Task 9", "2021-01-09", "Not Started", "Test 9", "Patient 9", "Room 9"),
        TaskListItem(10, "Task 10", "2021-01-10", "Not Started", "Test 10", "Patient 10", "Room 10"),
        TaskListItem(11, "Task 11", "2021-01-11", "Not Started", "Test 11", "Patient 11", "Room 11"),
        TaskListItem(12, "Task 12", "2021-01-12", "Not Started", "Test 12", "Patient 12", "Room 12"),
        TaskListItem(13, "Task 13", "2021-01-13", "Not Started", "Test 13", "Patient 13", "Room 13"),
        TaskListItem(14, "Task 14", "2021-01-14", "Not Started", "Test 14", "Patient 14", "Room 14"),
        TaskListItem(15, "Task 15", "2021-01-15", "Not Started", "Test 15", "Patient 15", "Room 15"),
        TaskListItem(16, "Task 16", "2021-01-16", "Not Started", "Test 16", "Patient 16", "Room 16"),
        TaskListItem(17, "Task 17", "2021-01-17", "Not Started", "Test 17", "Patient 17", "Room 17"),
        TaskListItem(18, "Task 18", "2021-01-18", "Not Started", "Test 18", "Patient 18", "Room 18"),
        TaskListItem(19, "Task 19", "2021-01-19", "Not Started", "Test 19", "Patient 19", "Room 19"),
        TaskListItem(20, "Task 20", "2021-01-20", "Not Started", "Test 20", "Patient 20", "Room 20"),
        TaskListItem(21, "Task 21", "2021-01-21", "Not Started", "Test 21", "Patient 21", "Room 21"),
        TaskListItem(22, "Task 22", "2021-01-22", "Not Started", "Test 22", "Patient 22", "Room 22"),
        TaskListItem(23, "Task 23", "2021-01-23", "Not Started", "Test 23", "Patient 23", "Room 23"),
        TaskListItem(24, "Task 24", "2021-01-24", "Not Started", "Test 24", "Patient 24", "Room 24"),
        TaskListItem(25, "Task 25", "2021-01-25", "Not Started", "Test 25", "Patient 25", "Room 25"),
        TaskListItem(26, "Task 26", "2021-01-26", "Not Started", "Test 26", "Patient 26", "Room 26"),
        TaskListItem(27, "Task 27", "2021-01-27", "Not Started", "Test 27", "Patient 27", "Room 27"),
        TaskListItem(28, "Task 28", "2021-01-28", "Not Started", "Test 28", "Patient 28", "Room 28"),
        TaskListItem(29, "Task 29", "2021-01-29", "Not Started", "Test 29", "Patient 29", "Room 29"),
        TaskListItem(30, "Task 30", "2021-01-30", "Not Started", "Test 30", "Patient 30", "Room 30")
    )
}