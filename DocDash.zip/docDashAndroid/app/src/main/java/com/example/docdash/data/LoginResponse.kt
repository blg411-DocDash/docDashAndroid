package com.example.docdash.data

data class LoginResponse(
    var token: String?,
    var role: String?,
)