package com.example.docdash.services

object ApiConstants {
    const val BASE_URL = "https://zfri5sujn7.execute-api.eu-central-1.amazonaws.com/"
    lateinit var TOKEN: String
}